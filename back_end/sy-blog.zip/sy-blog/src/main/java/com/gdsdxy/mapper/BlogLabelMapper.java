package com.gdsdxy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdsdxy.entity.BlogLabel;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BlogLabelMapper extends BaseMapper<BlogLabel> {
}

package com.gdsdxy.constants;

public class SystemConstants {
    // 用户默认昵称前缀
    public static final String USER_NICK_NAME_PREFIX = "sy_blog_user";
    // 用户上传文件存放地址
    public static final String UPLOAD_IMAGE_PATH = "E:\\毕业设计\\sy_shop\\back_end\\resources\\files";
}

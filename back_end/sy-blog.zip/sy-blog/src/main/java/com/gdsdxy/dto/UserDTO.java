package com.gdsdxy.dto;

import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String phone;
    private String account;
    private String icon;
    private String nickname;
}

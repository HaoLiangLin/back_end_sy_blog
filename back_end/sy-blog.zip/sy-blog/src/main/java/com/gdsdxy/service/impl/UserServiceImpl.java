package com.gdsdxy.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gdsdxy.dto.LoginFormDTO;
import com.gdsdxy.dto.PwdFormDTO;
import com.gdsdxy.dto.ResultVo;
import com.gdsdxy.dto.UserDTO;
import com.gdsdxy.entity.User;
import com.gdsdxy.mapper.UserMapper;
import com.gdsdxy.service.IUserService;
import com.gdsdxy.utils.RegexUtils;
import com.gdsdxy.utils.UserHolder;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.gdsdxy.constants.RedisConstants.*;
import static com.gdsdxy.constants.SystemConstants.USER_NICK_NAME_PREFIX;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public ResultVo sendCode(String phone) {
        // 校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            // 不符合，返回错误信息
            return ResultVo.fail("无效手机号");
        }
        String key = LOGIN_CODE_KEY + phone;
        // 符合，生成验证码
        String code = RandomUtil.randomNumbers(6);

        // 保存验证码，并设置有效期
        stringRedisTemplate.opsForValue().set(key, code, LOGIN_CODE_TTL, TimeUnit.MINUTES);

        // 发送验证码
        System.out.println("发送短信验证码成功！验证码：" + code);

        return ResultVo.ok();
    }

    @Override
    public ResultVo authPassword() {
        Long id = UserHolder.getUser().getId();
        return authPwd(id) ? ResultVo.ok() : ResultVo.fail();
    }

    @Override
    public ResultVo updatePassword(PwdFormDTO pwdFormDTO) {
        Long id = UserHolder.getUser().getId();

        UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("password", pwdFormDTO.getNewPassword()).eq("id", id);
        // 验证密码是否为空
        if (!authPwd(id)) {
            // 是，直接设置新密码
            return update(updateWrapper) ? ResultVo.ok() : ResultVo.fail("密码修改失败");
        }
        // 否，检查旧密码
        User user = query().eq("password", pwdFormDTO.getOldPassword()).eq("id", id).one();
        // 判断用户是否存在
        if (user == null) {
            // 不存在，返回错误信息
            return ResultVo.fail("旧密码错误");
        }
        // 存在
        return update(updateWrapper) ? ResultVo.ok() : ResultVo.fail("密码修改失败");
    }

    /**
     * 验证登录用户是否设置密码
     * @return Boolean
     */
    private Boolean authPwd(Long id) {
        User user = getById(id);
        // 判断密码是否不为空
        return StrUtil.isNotBlank(user.getPassword());
    }

    @Override
    public ResultVo login(LoginFormDTO loginFormDTO) {
        // 1. 判断用户是否账号登录
        if (StrUtil.isNotBlank(loginFormDTO.getAccount())) {
            // 账号登录
            return accountLogin(loginFormDTO.getAccount(), loginFormDTO.getPassword());
        }
        // 2. 判断用户是否手机登录
        if (StrUtil.isNotBlank(loginFormDTO.getPhone())) {
            // 手机登录
            return phoneLogin(loginFormDTO.getPhone(), loginFormDTO.getCode());
        }
        // 返回错误信息
        return ResultVo.fail("请求错误！");
    }

    /**
     * 手机号登录
     * @param phone 手机号
     * @param code 验证码
     * @return ResultVo
     */
    private ResultVo phoneLogin(String phone, String code){
        // 验证验证码
        ResultVo resultVo = checkCode(LOGIN_CODE_KEY, phone, code);
        if (StrUtil.isNotBlank(resultVo.getMessage())) {
            return resultVo;
        }

        // 正确，查询数据库
        User user = query().eq("phone", phone).eq("identity", 0).one();

        // 判断用户是否存在
        // 用户不存在
        if (user == null) {
            // 新注册一个用户
            user = createUserWithPhone(phone);
        }

        // 存在，将用户信息写入Redis
        String token = saveUser(user);

        // 返回token
        return ResultVo.ok(token);
    }

    /**
     * 验证验证码
     * @param prefix key前缀
     * @param phone 手机号
     * @param code 验证码
     * @return ResultVo
     */
    private ResultVo checkCode(String prefix, String phone, String code) {
        // 校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            return ResultVo.fail("手机号格式错误！");
        }

        String key = prefix + phone;
        // 从Redis中获取验证码
        String cacheCode = stringRedisTemplate.opsForValue().get(key);
        // 判断验证码是否正确
        if (cacheCode == null || !code.equals(cacheCode)) {
            // 错误，返回错误信息
            return ResultVo.fail("验证码错误");
        }
        return ResultVo.ok();
    }

    /**
     * 账号登录
     * @param account 账号
     * @param password 密码
     * @return ResultVo
     */
    private ResultVo accountLogin(String account, String password) {
        // 判断账户与密码是否为空
        if (StrUtil.isBlank(password)) {
            return ResultVo.fail("密码不能为空");
        }

        // 查询数据库
        User user = query().eq("account", account).eq("password", password).eq("identity", 0).one();

        // 判断用户是否存在
        if (user == null) {
            return ResultVo.fail("账号或密码错误");
        }

        // 存在，将用户信息写入Redis
        String token = saveUser(user);

        // 返回token
        return ResultVo.ok(token);
    }

    /**
     * 保存用户
     */
    private String saveUser(User user) {
        String token = IdUtil.fastSimpleUUID()+"-"+user.getId();

        // 设置Redis的key
        String key = LOGIN_USER_KEY + token;

        // 将user拷贝成UserDTO
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);

        // 将Bean转为Map类型，并存入Redis
        Map<String, Object> map = BeanUtil.beanToMap(userDTO, new HashMap<>(),
                CopyOptions.create()
                        .setIgnoreNullValue(true)
                        // 自定义将值转为字符串
                        // .setFieldValueEditor((fieldName, fieldValue) -> fieldValue.toString())
                        .setFieldValueEditor((fieldName, fieldValue) -> {
                            if (fieldValue == null) {
                                fieldValue = "";
                            } else {
                                fieldValue += "";
                            }
                            return fieldValue;
                        })
        );
        stringRedisTemplate.opsForHash().putAll(key, map);
        // 设置到期期限
        stringRedisTemplate.expire(key, LOGIN_USER_TTL, TimeUnit.MINUTES);

        return token;
    }

    /**
     * 注册用户
     */
    private User createUserWithPhone(String phone) {
        // 1.创建用户
        User user = new User();
        user.setPhone(phone);
        user.setAccount(USER_NICK_NAME_PREFIX + phone);
        user.setNickname(USER_NICK_NAME_PREFIX + RandomUtil.randomString(13));
        // 2.保存用户
        save(user);
        return user;
    }

}

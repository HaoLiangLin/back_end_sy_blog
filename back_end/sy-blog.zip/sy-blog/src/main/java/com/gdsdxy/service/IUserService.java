package com.gdsdxy.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gdsdxy.dto.LoginFormDTO;
import com.gdsdxy.dto.PwdFormDTO;
import com.gdsdxy.dto.ResultVo;
import com.gdsdxy.entity.User;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface IUserService extends IService<User> {
    /**
     * 用户登录
     * @param loginFormDTO 登录信息
     * @return ResultVo
     */
    ResultVo login(LoginFormDTO loginFormDTO);

    /**
     * 登录：发送验证码
     * @param phone 手机号
     * @return ResultVo
     */
    ResultVo sendCode(String phone);

    /**
     * 用户修改密码检查功能
     * @return ResultVo
     */
    ResultVo authPassword();

    /**
     * 修改密码
     * @param pwdFormDTO 密码信息
     * @return ResultVo
     */
    ResultVo updatePassword(PwdFormDTO pwdFormDTO);
}

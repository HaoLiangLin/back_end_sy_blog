package com.gdsdxy.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gdsdxy.entity.Album;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AlbumMapper extends BaseMapper<Album> {
}
